package CoffeeMachines;

public class OldCoffeeMachine {

	public String selectA() {
		return "A - Selected";
	}
	public String selectB() {
		return "B - Selected";
	}
}
